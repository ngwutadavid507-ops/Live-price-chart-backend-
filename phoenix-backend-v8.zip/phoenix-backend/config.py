"""
Phoenix Backend Config
All env vars loaded once here. Import `cfg` anywhere you need them.
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # ── Exchange Keys ─────────────────────────────────────────────────
    BYBIT_API_KEY:    str = os.getenv("BYBIT_API_KEY", "")
    BYBIT_API_SECRET: str = os.getenv("BYBIT_API_SECRET", "")

    # ── AI ────────────────────────────────────────────────────────────
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL:   str = "llama-3.3-70b-versatile"

    # ── Cache TTLs (seconds) ──────────────────────────────────────────
    MARKET_CACHE_TTL:   int = 10    # live prices refresh every 10s
    ANALYSIS_CACHE_TTL: int = 60    # indicator results refresh every 60s
    CANDLE_CACHE_TTL:   int = 30    # candle data

    # ── Signal Engine ─────────────────────────────────────────────────
    SIGNAL_MIN_AGREEMENTS: int   = 3
    SIGNAL_MIN_CONFIDENCE: float = 68.0

    # ── Data source priority ──────────────────────────────────────────
    # Tried in order; first success wins.
    EXCHANGE_PRIORITY: list = ["binance", "bybit", "okx", "mexc", "bingx"]
    FALLBACK_AGGREGATORS: list = ["coingecko", "coinpaprika"]

    # ── Server ────────────────────────────────────────────────────────
    HOST: str = "0.0.0.0"
    PORT: int = int(os.getenv("PORT", 8000))


cfg = Config()
