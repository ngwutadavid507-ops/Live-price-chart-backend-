from pydantic import BaseModel
from typing import Optional


class TrendResult(BaseModel):
    direction:   str    # "bullish" | "bearish" | "neutral"
    strength:    str    # "strong_bullish" | "weak_bullish" | "strong_bearish" | "weak_bearish" | "neutral"
    ema9:        float
    ema21:       float
    ema50:       float
    ema_aligned: bool   # True when ema9 > ema21 > ema50
    ema_spread:  float  # spread score 0-100


class MomentumResult(BaseModel):
    rsi:          float
    rsi_zone:     str   # "overbought" | "oversold" | "neutral"
    direction:    str


class VolatilityResult(BaseModel):
    atr:          float
    atr_pct:      float
    bb_upper:     float
    bb_middle:    float
    bb_lower:     float
    bb_squeeze:   bool
    direction:    str


class VolumeResult(BaseModel):
    volume_trend: str   # "rising" | "falling" | "flat"
    spike:        bool
    spike_ratio:  float
    direction:    str


class SignalResult(BaseModel):
    symbol:       str
    direction:    str        # "buy" | "sell" | "neutral"
    confidence:   float      # 0-100
    agreements:   int        # how many indicators agreed
    entry:        Optional[float] = None
    stop_loss:    Optional[float] = None
    take_profit:  Optional[float] = None
    fired:        bool        # True only when agreements >= 3 AND confidence > 68


class AnalysisResult(BaseModel):
    symbol:        str
    trend:         TrendResult
    momentum:      MomentumResult
    volatility:    VolatilityResult
    volume:        VolumeResult
    signal:        SignalResult
    market_score:  float      # 0-100 — Phase 2: rename to market_quality_score later
    timestamp:     int
