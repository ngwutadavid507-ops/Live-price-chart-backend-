from pydantic import BaseModel
from typing import Optional


class Position(BaseModel):
    symbol:     str
    amount:     float
    entry_price: float
    current_price: float
    pnl:        float
    pnl_pct:    float
    side:       str  # "long" | "short"


class PortfolioState(BaseModel):
    balance:    float
    pnl_24h:    float
    pct_24h:    float
    positions:  list[Position]
    total_value: float


class RiskMetrics(BaseModel):
    max_drawdown:   float
    sharpe_ratio:   float
    win_rate:       float
    profit_factor:  float
    avg_rr:         float   # average risk:reward


class BacktestRequest(BaseModel):
    symbol:     str
    strategy:   str   # "mean_reversion" | "breakout" | "momentum"
    timeframe:  str   # "1h" | "4h" | "1d"
    from_ts:    int   # unix ms
    to_ts:      int


class BacktestResult(BaseModel):
    strategy:       str
    symbol:         str
    win_rate:       float
    net_return_pct: float
    profit_factor:  float
    total_trades:   int
    equity_curve:   list[float]
