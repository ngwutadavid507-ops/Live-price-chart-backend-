"""
/markets — prices, ticker, market summary, candles.
Powers: dashboard.js, markets.js, ticker feed.
"""

from fastapi import APIRouter, Query, WebSocket
from cache.market_cache import market_cache
from cache.analysis_cache import analysis_cache
from services.binance import get_klines
from utils.validators import validate_symbol, validate_timeframe, validate_limit
from models.market import MarketSummary, CandleBar
from websocket.ticker_ws import ticker_endpoint

router = APIRouter()


@router.get("/summary")
async def market_summary():
    """Global market overview — powers Dashboard macro view."""
    analyses = analysis_cache.all()
    if not analyses:
        # Fast fallback: compute from price cache only
        assets = market_cache.all()
        return {
            "bullish_count":     0,
            "bearish_count":     0,
            "neutral_count":     len(assets),
            "avg_market_score":  50.0,
            "strongest_bullish": [],
            "strongest_bearish": [],
            "total_tracked":     len(assets),
        }

    bullish  = [a for a in analyses if a.signal.direction == "buy"]
    bearish  = [a for a in analyses if a.signal.direction == "sell"]
    neutral  = [a for a in analyses if a.signal.direction == "neutral"]
    avg_score = sum(a.market_score for a in analyses) / len(analyses) if analyses else 50.0

    return MarketSummary(
        bullish_count=len(bullish),
        bearish_count=len(bearish),
        neutral_count=len(neutral),
        avg_market_score=round(avg_score, 2),
        strongest_bullish=[a.symbol for a in sorted(bullish, key=lambda x: x.market_score, reverse=True)[:5]],
        strongest_bearish=[a.symbol for a in sorted(bearish, key=lambda x: x.market_score)[:5]],
        total_tracked=len(analyses),
    )


@router.get("/pairs")
async def all_pairs(
    limit: int = Query(100, ge=1, le=2000),
    search: str = Query("", description="Filter by symbol prefix"),
):
    """All tracked assets — powers markets.js asset browser."""
    assets = market_cache.all()
    if search:
        assets = [a for a in assets if search.upper() in a["symbol"]]
    assets = sorted(assets, key=lambda x: x["volume_raw"], reverse=True)
    return {"count": len(assets), "assets": assets[:limit]}


@router.get("/ticker")
async def ticker():
    """Hot symbols for the top ticker strip."""
    return {"symbols": market_cache.hot()}


@router.get("/trending")
async def trending(limit: int = Query(20, ge=1, le=50)):
    """
    Highest market-score assets — sorted descending.
    Falls back to volume sort if analysis not ready.
    """
    analyses = analysis_cache.all()
    if analyses:
        ranked = sorted(analyses, key=lambda x: x.market_score, reverse=True)[:limit]
        return {"ranked_by": "market_score", "assets": [
            {"symbol": a.symbol, "market_score": a.market_score,
             "direction": a.signal.direction}
            for a in ranked
        ]}
    # Fallback
    hot = market_cache.hot()[:limit]
    return {"ranked_by": "volume", "assets": hot}


@router.get("/candles/{symbol}")
async def candles(
    symbol: str,
    interval: str = Query("1h", description="1m|5m|15m|30m|1h|4h|1d|1w"),
    limit:    int  = Query(100, ge=10, le=500),
):
    """OHLCV candles for charting — powers analysis.js candlestick chart."""
    sym = validate_symbol(symbol)
    tf  = validate_timeframe(interval)
    lim = validate_limit(limit)
    bars = await get_klines(sym, interval=tf, limit=lim)
    return {"symbol": sym, "interval": tf, "count": len(bars), "candles": bars}


@router.websocket("/ws/ticker")
async def ws_ticker(ws: WebSocket):
    """Live price stream — frontend services/websocket.js connects here."""
    await ticker_endpoint(ws)
