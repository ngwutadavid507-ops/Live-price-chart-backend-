"""
/analysis — full technical analysis per symbol.
Powers: analysis.js — all indicator panels, pattern detection, S&R.
"""

from fastapi import APIRouter, Query
from cache.analysis_cache import analysis_cache
from utils.validators import validate_symbol, validate_timeframe

router = APIRouter()


@router.get("/{symbol}")
async def analyse(
    symbol:   str,
    interval: str = Query("1h"),
):
    """
    Full analysis for a symbol.
    Returns: trend, momentum, volatility, volume, signal, market_score.
    Serves cached result if available; computes fresh if not.
    """
    sym    = validate_symbol(symbol)
    result = await analysis_cache.get_or_compute(sym)
    if not result:
        return {"error": f"Unable to analyse {sym} — insufficient data"}
    return result


@router.get("/{symbol}/indicators")
async def indicators_only(symbol: str):
    """
    Lightweight endpoint returning just the indicator values.
    Used when the frontend only needs the indicator panel, not full analysis.
    """
    sym    = validate_symbol(symbol)
    result = await analysis_cache.get_or_compute(sym)
    if not result:
        return {"error": "Insufficient data"}
    return {
        "symbol":   sym,
        "trend":    result.trend,
        "momentum": result.momentum,
        "volatility": result.volatility,
        "volume":   result.volume,
    }


@router.get("/{symbol}/score")
async def market_score(symbol: str):
    """Quick market score lookup for a symbol."""
    sym    = validate_symbol(symbol)
    result = await analysis_cache.get_or_compute(sym)
    if not result:
        return {"symbol": sym, "market_score": 50.0}
    return {"symbol": sym, "market_score": result.market_score}
